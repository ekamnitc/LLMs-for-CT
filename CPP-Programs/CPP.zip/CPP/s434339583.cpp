#include<bits/stdc++.h>
using namespace std;

#define ll long long int

	
	
int main(){
	int t;
	cin>>t;
	
	int ans = t * (t+1);
	ans>>=1;
	
	cout<<ans<<endl;
}
