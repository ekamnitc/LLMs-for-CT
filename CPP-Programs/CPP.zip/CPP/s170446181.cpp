#include<bits/stdc++.h>

using namespace std;
int main(){
    int d;
    cin >> d;
    if(d==22) cout << "Christmas Eve Eve Eve" << endl;
    else if(d==23) cout << "Christmas Eve Eve"  << endl;
    else if(d==24) cout << "Christmas Eve" << endl;
    else if(d==25) cout << "Christmas" << endl;
    return 0;
}