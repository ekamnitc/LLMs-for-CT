#include<bits/stdc++.h>
using namespace std;

int main(){
  ios_base::sync_with_stdio(false);
  cin.tie(NULL);
//  long long int n,k,ans=1;
 long long int a,b;
  cin>>a>>b;
  if((a>=10) ||(b>=10))
    cout<<"-1";
  else
    cout<<a*b;

  }
