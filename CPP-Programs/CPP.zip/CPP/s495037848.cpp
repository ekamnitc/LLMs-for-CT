#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define INF 0x3f3f3f3f
const int maxn=1e6+3;
 
int main()
{
    int n,k;cin>>n>>k;
    cout<<n-k+1<<endl;
    return 0;
}