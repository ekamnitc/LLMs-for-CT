#include <bits/stdc++.h>
#include <math.h>
using namespace std;
void ABC70(void);
void ABC71(void);
void ABC72(void);
void ABC73(void);
void ABC74(void);
void ABC75(void);
void ABC76(void);
void ABC77(void);
void ABC78(void);
void ABC79(void);

int main(void){
    ABC72();
}

void ABC72(){
    string s;
    cin>>s;
    for(int i=0;i<s.length();i+=2){
        cout<<s[i];
    }
    cout<<endl;
}