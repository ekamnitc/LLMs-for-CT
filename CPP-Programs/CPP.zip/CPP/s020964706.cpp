#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
   int a,c,x;
   cin>>a>>c>>x;
   (a+c>=x)? cout<<"Yes" : cout<<"No";
}