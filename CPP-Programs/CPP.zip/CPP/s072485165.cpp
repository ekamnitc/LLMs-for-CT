#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
const long long INF = 1LL << 60;
const int MOD = 1000000007;
using pint = pair<ll, ll>;

int main(){
    char x;
    cin >> x;
    if(x<='Z' && x>='A')cout <<'A' <<endl;
    else
      cout << 'a' << endl;
    return 0;
}