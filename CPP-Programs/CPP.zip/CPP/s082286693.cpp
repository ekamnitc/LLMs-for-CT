#include <iostream>
#include<string>
 using namespace std;

 int main(){
char s[2];
 cin>>s;
 s[0]++;
 cout<<s;
 }
