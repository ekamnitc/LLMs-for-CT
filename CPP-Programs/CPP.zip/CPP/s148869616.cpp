#include <bits/stdc++.h>
#define rep(i, n) for (int i = 0; i < (int)(n); i++)
using namespace std;
using ll = long long;
using p = pair<int,int>;
const long long INF = 1ll << 60;



int main() {
  int K; cin >> K;
  int ans = K/2 * (K - K/2);
  cout << ans << endl;


	return 0;
}

