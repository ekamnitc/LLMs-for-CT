#include <bits/stdc++.h>
using namespace std;
int main(void){

    char a, b;
    cin >> a >> b ;
    
    //*
    if(a == b){
        cout << "H" << endl;
    } else {
        cout << "D" << endl;
    }
    //*/
    
    //cout << a * 800 - a / 15 * 200 << endl;

    return 0; 
}
