#include <bits/stdc++.h>
using namespace std;

int main () {
  string s,t,u;
  cin >> s >> t >> u;

  cout << 'A' << t[0] << 'C' << endl;
  
  return 0;
}
